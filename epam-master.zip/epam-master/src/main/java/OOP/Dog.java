package OOP;

public class Dog extends Animal {

    public Dog() {
        super("brown",4,true);
    }
}

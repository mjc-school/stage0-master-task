package AlgorithmAndArrays;

public enum Complexity {

        O_LOG_N,
        O_N_2,
        O_FACTORIAL_N,
        O_2_N,
        O_N_LOG_N,
        O_1,
        O_N
}
